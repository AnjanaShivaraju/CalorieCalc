package calorie;

public class Calorie {

	public static void main(String[] args) {

		CalorieCalculator calculator = new CalorieCalculator();
		calculator.run();
	}
}
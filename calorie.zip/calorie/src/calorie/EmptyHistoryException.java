package calorie;

class EmptyHistoryException extends Exception {
public EmptyHistoryException(String message) {
super(message);
}
}
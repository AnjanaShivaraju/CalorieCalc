package calorie;

class InvalidActivityLevelException extends Exception {
	/*
	 * Constructs a new InvalidActivityLevelException with the specified message.
	 * 
	 */
	public InvalidActivityLevelException(String message) {
		super(message);
	}
}
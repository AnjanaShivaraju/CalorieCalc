package calorie;

class InvalidException extends Exception {
	public InvalidException(String message) {
		super(message);
	}
}